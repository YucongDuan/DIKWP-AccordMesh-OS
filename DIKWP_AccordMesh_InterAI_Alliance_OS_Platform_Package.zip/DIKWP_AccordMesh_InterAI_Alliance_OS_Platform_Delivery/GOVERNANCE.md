# Governance

## Roles
- Chief architect: theory and protocol coherence.
- Protocol maintainers: schemas, runtime and releases.
- Evidence stewards: claims, challenges and replication.
- Safety stewards: threat model, kill and repair.
- Beneficiary representatives: affected-party rights and appeal.

No canonical release may depend on one person alone. High-impact changes require protocol, safety and public-interest review.
