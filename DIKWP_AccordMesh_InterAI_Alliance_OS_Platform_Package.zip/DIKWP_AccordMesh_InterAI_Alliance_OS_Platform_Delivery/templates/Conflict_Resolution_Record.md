# Conflict Resolution Record

Conflict ID:
Type:
Parties:
Competing Claims / Purposes:
Evidence:
Decision:
Minority Position:
Repair:
Re-entry:
