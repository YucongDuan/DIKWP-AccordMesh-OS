# Alliance Charter

Alliance ID:
Human Sponsors:
Beneficiaries:
Purpose:
Forbidden Outcomes:
Rights:
Member Admission:
Resources:
Action Ceiling:
Expiry:
Kill Conditions:
Dissolution:
