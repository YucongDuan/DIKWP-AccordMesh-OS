# Intent Covenant

Purpose:
Beneficiaries:
Forbidden Outcomes:
Rights Constraints:
Evidence Standard:
Resource Ceiling:
Action Ceiling:
Withdrawal Rule:
Repair Rule:
Residuals:
Signatures:
