# Federation Memorandum of Understanding

Parties:
Trust Domains:
Shared Protocols:
Data Boundaries:
Purpose / Beneficiaries:
Security and Incident Notice:
Resource Accounting:
IP / Open-source Terms:
Exit and Dissolution:
Signatures:
