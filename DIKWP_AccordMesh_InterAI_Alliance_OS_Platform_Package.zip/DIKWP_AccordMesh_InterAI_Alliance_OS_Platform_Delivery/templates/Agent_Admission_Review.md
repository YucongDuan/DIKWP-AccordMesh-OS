# Agent Admission Review

Agent ID:
Human Sponsor:
Trust Domain:
Runtime Version:
Capabilities:
Purpose Domains:
Prohibited Actions:
Action Ceiling:
Evidence Grade:
Identity Proof:
Kill Conditions:
Decision:
