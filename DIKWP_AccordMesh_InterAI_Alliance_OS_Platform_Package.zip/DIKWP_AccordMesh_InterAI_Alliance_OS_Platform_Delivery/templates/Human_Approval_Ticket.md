# Human Approval Ticket

Action ID:
Action Grade:
Description:
Reversibility:
Affected Parties:
Evidence:
Decision: Approve / Deny / Conditions
Approver:
Expiry:
