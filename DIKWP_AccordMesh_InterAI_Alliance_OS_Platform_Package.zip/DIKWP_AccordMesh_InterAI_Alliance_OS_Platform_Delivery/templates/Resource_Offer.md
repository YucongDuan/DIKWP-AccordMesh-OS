# Resource Offer

Agent ID:
Resource Type:
Quantity / Unit:
Measurement Status:
Method / Range:
Purpose Scope:
Cost:
Physical Energy / Carbon:
Expiry:
Prohibited Use:
