# Coalition Mission

Mission ID:
Purpose Domain:
Required Capabilities:
Success Proof:
Action Grade:
Resource Budget:
Human Owner:
Kill Conditions:
