# AccordMesh Protocol 0.1

State: `DISCOVER -> VERIFY -> PROPOSE -> NEGOTIATE -> COMMIT -> EXECUTE -> CHALLENGE -> REVIEW -> DISSOLVE`.

Every transition carries identity, intent covenant, DIKWP packet, evidence state, resource state, action grade, expiry, kill and repair metadata.

Hard exclusions precede coalition scoring. Purpose mismatch, invalid identity, insufficient action ceiling, forbidden behavior or resource breach must reject the candidate.
