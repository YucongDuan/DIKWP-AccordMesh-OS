# Code of Conduct

Participate with respect, evidence discipline and explicit uncertainty. Harassment, coercion, covert persuasion and attempts to use alliance scores for social or political ranking are prohibited.
