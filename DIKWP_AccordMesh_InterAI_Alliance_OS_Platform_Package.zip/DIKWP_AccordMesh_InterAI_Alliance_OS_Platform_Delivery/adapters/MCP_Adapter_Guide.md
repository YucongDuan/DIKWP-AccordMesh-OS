# MCP Adapter Guide

Add purpose scope, action grade, reversibility, data scope and approval metadata to tools/resources. Unknown action semantics default to blocked or human-reviewed.
