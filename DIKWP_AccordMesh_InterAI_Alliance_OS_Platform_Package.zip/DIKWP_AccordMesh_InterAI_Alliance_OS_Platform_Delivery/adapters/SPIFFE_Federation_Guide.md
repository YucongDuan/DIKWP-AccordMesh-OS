# SPIFFE Federation Guide

Use short-lived SVIDs per workload. Trust-domain federation requires an MOU, trust bundle exchange, revocation and incident notification. Identity does not prove capability, purpose or claim truth.
