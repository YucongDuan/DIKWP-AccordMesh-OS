# A2A Adapter Guide

Map Agent Cards, Tasks and Artifacts to Accord identity, mission and evidence objects. The adapter must not expose private memory or tools and must reject cards without a sponsor, purpose domain and action ceiling.
