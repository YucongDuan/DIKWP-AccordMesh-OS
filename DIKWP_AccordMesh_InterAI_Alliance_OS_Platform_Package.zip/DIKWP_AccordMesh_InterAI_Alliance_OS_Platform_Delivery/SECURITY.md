# Security Policy

Report identity spoofing, credential delegation, purpose drift, replay tampering, hidden external actions, resource escape or undisclosed alliance channels privately to the designated security steward. Never include live secrets in issues or replay bundles.
