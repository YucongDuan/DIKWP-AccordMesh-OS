import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/"src"))
from accordmesh_core import AccordLedger,ActionGuardian,AgentCard,IntentCovenant,MissionProposal,ResourceBroker,form_coalition,stable_hash
class Tests(unittest.TestCase):
 def setUp(self):
  self.l=AccordLedger(); self.c=IntentCovenant("C1","research",["public"],["surveillance"],["human review"],"challenge",{"tokens":100,"cost":10},"A3","any","expiry","retract",["human"])
 def test_budget(self): self.assertFalse(ResourceBroker(self.c.resource_ceiling,self.l,"t").reserve("a",{"tokens":101})[0])
 def test_unknown_resource(self): self.assertFalse(ResourceBroker(self.c.resource_ceiling,self.l,"t").reserve("a",{"gpu":1})[0])
 def test_a3_two_humans(self):
  g=ActionGuardian(self.c,self.l,"t"); self.assertFalse(g.authorize("A3",["one"],True,"x")[0]); self.assertTrue(g.authorize("A3",["one","two"],True,"x")[0])
 def test_a4_never_executes(self): self.c.action_grade_ceiling="A4"; self.assertFalse(ActionGuardian(self.c,self.l,"t").authorize("A4",["1","2"],True,"x")[0])
 def test_irreversible_a2_blocked(self): self.assertFalse(ActionGuardian(self.c,self.l,"t").authorize("A2",["1"],False,"x")[0])
 def test_purpose_mismatch(self):
  a=[AgentCard("x","x","p","h","d",["search"],["marketing"],[])]; m=MissionProposal("m","research","research",["search"],"A1",{"tokens":10},["proof"],["kill"],"human"); self.assertEqual(form_coalition(a,self.c,m),[])
 def test_action_ceiling(self):
  a=[AgentCard("x","x","p","h","d",["search"],["research"],[],action_grade_ceiling="A1")]; m=MissionProposal("m","x","research",["search"],"A2",{"tokens":10},["proof"],["kill"],"human"); self.assertEqual(form_coalition(a,self.c,m),[])
 def test_hash_stable(self): self.assertEqual(stable_hash({"b":2,"a":1}),stable_hash({"a":1,"b":2}))
if __name__=="__main__": unittest.main()
