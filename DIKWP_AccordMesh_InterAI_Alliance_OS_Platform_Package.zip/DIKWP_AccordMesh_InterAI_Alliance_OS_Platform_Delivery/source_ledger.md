# Source Ledger

Snapshot date: 2026-07-16/17. GitHub counts and project status are time-sensitive.

1. YucongDuan GitHub portfolio — https://github.com/YucongDuan?tab=repositories&sort=updated
2. DIKWP-MESH² — https://github.com/YucongDuan/DIKWP-MESH-
3. DIKWP-PACT — https://github.com/YucongDuan/DIKWP-PACT-v0.1.0
4. DIKWP-AgentMesh — https://github.com/YucongDuan/DIKWP-AgentMesh-OS-Platform-Delivery-Package
5. DIKWP-RESONANCE — https://github.com/YucongDuan/DIKWP-RESONANCE-MVP
6. A2A — https://a2a-protocol.org/latest/
7. MCP — https://modelcontextprotocol.io/specification/
8. SPIFFE — https://spiffe.io/docs/latest/spiffe-about/overview/
9. CloudEvents — https://cloudevents.io/
10. W3C Verifiable Credentials 2.0 — https://www.w3.org/TR/vc-data-model-2.0/
11. JSON Schema 2020-12 — https://json-schema.org/draft/2020-12
12. Kofman et al. (2026), Defining Life: A Conversation — https://doi.org/10.13133/2532-5876/19492

ResearchGate technical reports and GitHub prototypes are treated as theory/engineering inputs, not automatically as peer-reviewed scientific findings.
