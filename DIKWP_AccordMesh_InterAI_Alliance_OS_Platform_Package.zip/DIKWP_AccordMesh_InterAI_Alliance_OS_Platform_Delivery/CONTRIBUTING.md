# Contributing

Use an issue before changing core semantics. Pull requests must include tests, an evidence note, security impact, migration impact and residual uncertainty. Do not add live provider credentials or autonomous external actions.
