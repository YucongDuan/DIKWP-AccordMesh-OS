from __future__ import annotations
import argparse, json
from pathlib import Path
from uuid import uuid4
from accordmesh_core import AccordLedger, ActionGuardian, AgentCard, IntentCovenant, MissionProposal, ResourceBroker, create_replay_bundle, form_coalition

def load_agents(path):
    data=json.loads(path.read_text(encoding="utf-8")); out=[]
    for raw in data:
        item=dict(raw); meta=item.pop("metadata",{}); item.pop("resource_offers",None); item.pop("mcp_endpoints",None)
        for k,d in [("model_family",item.get("provider","unknown")),("purpose_fidelity",.82),("evidence_trust",.75),("repair_history",.8),("latency_score",.72),("energy_efficiency",.65)]: item[k]=meta.get(k,d)
        out.append(AgentCard(**item))
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--scenario",default="research",choices=["research","conflict","budget","high-risk"]); ap.add_argument("--out",default="data/sample_replay_bundle.json"); a=ap.parse_args()
    root=Path(__file__).resolve().parents[1]; agents=load_agents(root/"data/sample_agent_registry.json"); cov=IntentCovenant(**json.loads((root/"data/sample_alliance_charter.json").read_text()))
    trace=f"trace-{uuid4()}"; ledger=AccordLedger(); ledger.emit("accordmesh","accord.alliance.discover",trace,"demo-alliance",{"agents":[x.agent_id for x in agents]})
    grade="A1"; domain="research"; budget={"tokens":80000,"cost":20,"watt_hours":350}
    if a.scenario=="conflict": domain="political-persuasion"
    if a.scenario=="budget": budget["tokens"]=120000
    if a.scenario=="high-risk": grade="A3"
    mission=MissionProposal("MIS-DEMO-001","Produce an auditable cross-agent research brief",domain,["search_synthesis","evidence_challenge","purpose_assurance"],grade,budget,["all key claims have sources","independent challenge completed","resource proof attached"],["fabricated source","purpose drift","resource ceiling exceeded","hidden external action"],"Research Lab Owner")
    ledger.emit("mission-compiler","accord.mission.proposed",trace,mission.mission_id,mission.__dict__)
    coalition=form_coalition(agents,cov,mission)
    broker=ResourceBroker(cov.resource_ceiling,ledger,trace)
    if not coalition:
        result={"status":"rejected","reason":"no compatible coalition"}; bundle=create_replay_bundle([],cov,mission,ledger,broker,result)
    else:
        selected=[x for x,_ in coalition]; ledger.emit("coalition-orchestrator","accord.coalition.formed",trace,mission.mission_id,{"members":[{"agent_id":x.agent_id,"score":s} for x,s in coalition]})
        ok,reason=broker.reserve("coalition",budget); guardian=ActionGuardian(cov,ledger,trace); approvals=[] if grade in {"A0","A1"} else ["human-1"]
        authorized,auth=guardian.authorize(grade,approvals,True,mission.title)
        if not ok or not authorized:
            result={"status":"blocked","resource":reason,"authorization":auth}; ledger.emit("accordmesh","accord.mission.blocked",trace,mission.mission_id,result)
        else:
            claims=[{"claim":"Purpose contracts make assumptions explicit.","source":"DIKWP-PACT public design","status":"supported-with-scope"},{"claim":"A2A and MCP solve different interoperability layers.","source":"official specifications","status":"supported"}]
            ledger.emit("agent:critic","accord.evidence.challenge",trace,mission.mission_id,{"challenge":"Interoperability does not imply safety."}); ledger.emit("agent:steward","accord.audit.completed",trace,mission.mission_id,{"purpose_fidelity":.96,"evidence_completeness":.91})
            result={"status":"completed","claims":claims,"residuals":["Offline synthetic demo","Physical energy is estimated, not measured"],"semantic_yield_proxy":round(2/max(1,budget["cost"]),4)}
        bundle=create_replay_bundle(selected,cov,mission,ledger,broker,result)
    out=Path(a.out); out=out if out.is_absolute() else root/out; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(bundle,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"scenario":a.scenario,"status":bundle["result"].get("status"),"members":[x["agent_id"] for x in bundle["agents"]],"output":str(out)},ensure_ascii=False,indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
