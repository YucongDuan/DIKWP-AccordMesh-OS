from __future__ import annotations
from typing import Any, Dict

def from_a2a_agent_card(card: Dict[str, Any], sponsor: str, trust_domain: str) -> Dict[str, Any]:
    return {"agent_id": card.get("name") or card.get("id","unknown"), "name":card.get("name","A2A Agent"), "provider":"a2a", "runtime_version":card.get("version","unknown"), "human_sponsor":sponsor, "trust_domain":trust_domain, "a2a_endpoint":card.get("url"), "capabilities":[x.get("id",str(x)) if isinstance(x,dict) else str(x) for x in card.get("skills",[])], "purpose_domains":card.get("extensions",{}).get("purpose_domains",[]), "prohibited_actions":card.get("extensions",{}).get("prohibited_actions",[]), "action_grade_ceiling":card.get("extensions",{}).get("action_grade_ceiling","A0")}

def from_mcp_tool(tool: Dict[str, Any]) -> Dict[str, Any]:
    meta=tool.get("_meta",{})
    return {"capability":tool.get("name"),"description":tool.get("description",""),"input_schema":tool.get("inputSchema",{}),"purpose_scope":meta.get("purpose_scope",[]),"action_grade":meta.get("action_grade","A2"),"reversible":meta.get("reversible",False),"human_approval":meta.get("human_approval",True)}

def to_cloudevent(event_type: str, source: str, subject: str, trace_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
    from datetime import datetime, timezone
    import uuid
    return {"specversion":"1.0","id":str(uuid.uuid4()),"source":source,"type":event_type,"time":datetime.now(timezone.utc).isoformat().replace("+00:00","Z"),"subject":subject,"datacontenttype":"application/json","trace_id":trace_id,"data":data}
