from __future__ import annotations
import argparse, json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
ROOT=Path(__file__).resolve().parents[1]
AGENTS=json.loads((ROOT/"data/sample_agent_registry.json").read_text()); COVENANT=json.loads((ROOT/"data/sample_alliance_charter.json").read_text())
class Handler(BaseHTTPRequestHandler):
    server_version="AccordMeshLocal/0.1"
    def _json(self,status,obj):
        raw=json.dumps(obj,ensure_ascii=False,indent=2).encode(); self.send_response(status); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        p=urlparse(self.path).path
        if p=="/health": return self._json(200,{"status":"ok","network_scope":"localhost-only"})
        if p in {"/.well-known/agent-card.json","/agents"}: return self._json(200,{"agents":AGENTS,"residual":"A2A-like local demonstration, not a conformance claim"})
        if p=="/covenant": return self._json(200,COVENANT)
        if p=="/mcp/tools": return self._json(200,{"tools":[{"name":"accordmesh.propose_mission","description":"Create a non-executing mission proposal","inputSchema":{"type":"object","properties":{"title":{"type":"string"}},"required":["title"]},"_meta":{"purpose_scope":["research"],"action_grade":"A1","reversible":True,"human_approval":False}}]})
        return self._json(404,{"error":"not found"})
    def do_POST(self):
        p=urlparse(self.path).path; n=int(self.headers.get("Content-Length","0"))
        try: body=json.loads(self.rfile.read(n).decode()) if n else {}
        except json.JSONDecodeError: return self._json(400,{"error":"invalid JSON"})
        if p=="/tasks": return self._json(202,{"task_id":"local-demo-task","state":"submitted","action_grade":"A1","input":body,"note":"No external action is executed."})
        if p=="/events": return self._json(202,{"accepted":True,"event":body})
        if p=="/resources/offers": return self._json(202,{"accepted":True,"offer":body})
        if p.startswith("/actions/") and p.endswith("/approval"): return self._json(200,{"recorded":True,"approval":body})
        return self._json(404,{"error":"not found"})
    def log_message(self,fmt,*args): print("[local-gateway] "+fmt%args)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--bind",default="127.0.0.1"); ap.add_argument("--port",type=int,default=8787); a=ap.parse_args()
    if a.bind not in {"127.0.0.1","localhost","::1"}: raise SystemExit("Reference gateway only permits localhost binding.")
    s=ThreadingHTTPServer((a.bind,a.port),Handler); print(f"AccordMesh local gateway on http://{a.bind}:{a.port}")
    try:s.serve_forever()
    except KeyboardInterrupt:pass
    finally:s.server_close()
    return 0
if __name__=="__main__": raise SystemExit(main())
