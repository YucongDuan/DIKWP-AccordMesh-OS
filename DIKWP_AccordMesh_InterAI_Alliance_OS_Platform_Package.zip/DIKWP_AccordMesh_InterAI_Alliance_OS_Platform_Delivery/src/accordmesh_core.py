from __future__ import annotations
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from hashlib import sha256
from typing import Any, Dict, List, Optional, Tuple
import json, uuid

ACTION_ORDER = {"A0":0,"A1":1,"A2":2,"A3":3,"A4":4}

def utc_now(): return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")
def stable_hash(obj): return sha256(json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(",",":")).encode()).hexdigest()

@dataclass
class AgentCard:
    agent_id:str; name:str; provider:str; human_sponsor:str; trust_domain:str
    capabilities:List[str]; purpose_domains:List[str]; prohibited_actions:List[str]
    runtime_version:str="unknown"; action_grade_ceiling:str="A1"; evidence_grade:str="E1"; model_family:str="unknown"
    spiffe_id:Optional[str]=None; a2a_endpoint:Optional[str]=None; status:str="active"
    purpose_fidelity:float=.8; evidence_trust:float=.7; repair_history:float=.8; latency_score:float=.7; energy_efficiency:float=.6

@dataclass
class IntentCovenant:
    covenant_id:str; purpose:str; beneficiaries:List[str]; forbidden_outcomes:List[str]; rights_constraints:List[str]
    evidence_standard:str; resource_ceiling:Dict[str,float]; action_grade_ceiling:str; withdrawal_rule:str; dissolution_rule:str; repair_rule:str; signatories:List[str]
    residuals:List[str]=field(default_factory=list); expires_at:str=""

@dataclass
class MissionProposal:
    mission_id:str; title:str; purpose_domain:str; required_capabilities:List[str]; action_grade:str; resource_budget:Dict[str,float]; success_proof:List[str]; kill_conditions:List[str]; human_owner:str

@dataclass
class InteractionEvent:
    id:str; source:str; type:str; time:str; trace_id:str; subject:str; data:Dict[str,Any]; specversion:str="1.0"; datacontenttype:str="application/json"

class AccordLedger:
    def __init__(self): self.events=[]
    def emit(self,source,event_type,trace_id,subject,data):
        e=InteractionEvent(str(uuid.uuid4()),source,event_type,utc_now(),trace_id,subject,data); self.events.append(e); return e
    def to_dicts(self): return [asdict(e) for e in self.events]

class ResourceBroker:
    def __init__(self,ceiling,ledger,trace_id):
        self.ceiling={k:float(v) for k,v in ceiling.items()}; self.used={k:0.0 for k in self.ceiling}; self.ledger=ledger; self.trace_id=trace_id; self.frozen=False
    def reserve(self,agent_id,request):
        if self.frozen: return False,"resource broker is frozen"
        for key,amount in request.items():
            if key not in self.ceiling: return False,f"resource {key!r} is not authorized"
            if self.used.get(key,0)+float(amount)>self.ceiling[key]:
                self.ledger.emit("resource-broker","accord.resource.denied",self.trace_id,agent_id,{"request":request,"reason":"ceiling exceeded"}); return False,f"resource ceiling exceeded for {key}"
        for key,amount in request.items(): self.used[key]=self.used.get(key,0)+float(amount)
        self.ledger.emit("resource-broker","accord.resource.reserved",self.trace_id,agent_id,{"request":request,"used":dict(self.used),"ceiling":dict(self.ceiling)}); return True,"reserved"
    def utilization(self): return {k:(self.used[k]/v if v else 0) for k,v in self.ceiling.items()}

class ActionGuardian:
    def __init__(self,covenant,ledger,trace_id): self.covenant=covenant; self.ledger=ledger; self.trace_id=trace_id
    def authorize(self,action_grade,human_approvals,reversible,description):
        if ACTION_ORDER[action_grade]>ACTION_ORDER[self.covenant.action_grade_ceiling]: return False,"action grade exceeds covenant ceiling"
        if action_grade=="A4": return False,"A4 is preparation-only in the reference runtime"
        required=1 if action_grade=="A2" else 2 if action_grade=="A3" else 0
        if action_grade in {"A2","A3"} and not reversible: return False,"A2/A3 reference actions must be reversible"
        if len(set(human_approvals))<required:
            self.ledger.emit("action-guardian","accord.action.pending",self.trace_id,description,{"grade":action_grade,"required":required,"approvals":human_approvals}); return False,f"{required} distinct human approval(s) required"
        self.ledger.emit("action-guardian","accord.action.authorized",self.trace_id,description,{"grade":action_grade,"approvals":sorted(set(human_approvals)),"reversible":reversible}); return True,"authorized"

def capability_fit(agent,required): return 1.0 if not required else sum(c in agent.capabilities for c in required)/len(required)
def intent_compatibility(agent,covenant,mission):
    domain=1.0 if mission.purpose_domain in agent.purpose_domains else 0.0
    grade=1.0 if ACTION_ORDER[mission.action_grade]<=ACTION_ORDER[agent.action_grade_ceiling] else 0.0
    return max(0,min(1,.45*domain+.25*grade+.15*agent.purpose_fidelity+.15*agent.repair_history))
def coalition_score(agent,covenant,mission,selected_families):
    diversity=1.0 if agent.model_family not in selected_families else .25
    return round(max(0,min(1,.25*capability_fit(agent,mission.required_capabilities)+.25*intent_compatibility(agent,covenant,mission)+.15*agent.evidence_trust+.10*agent.energy_efficiency+.10*diversity+.10*agent.repair_history+.05*agent.latency_score)),4)
def form_coalition(agents,covenant,mission,max_members=5):
    remaining=[a for a in agents if a.status=="active" and mission.purpose_domain in a.purpose_domains and ACTION_ORDER[mission.action_grade]<=ACTION_ORDER[a.action_grade_ceiling]]
    chosen=[]; families=[]
    while remaining and len(chosen)<max_members:
        ranked=sorted(((a,coalition_score(a,covenant,mission,families)) for a in remaining),key=lambda x:x[1],reverse=True)
        agent,score=ranked[0]
        if score<.35: break
        chosen.append((agent,score)); families.append(agent.model_family); remaining=[a for a in remaining if a.agent_id!=agent.agent_id]
    return chosen

def create_replay_bundle(agents,covenant,mission,ledger,resources,result):
    bundle={"bundle_id":str(uuid.uuid4()),"created_at":utc_now(),"agents":[asdict(a) for a in agents],"covenant":asdict(covenant),"mission":asdict(mission),"events":ledger.to_dicts(),"resource_summary":{"ceiling":resources.ceiling,"used":resources.used,"utilization":resources.utilization()},"result":result}
    bundle["integrity_hash"]=stable_hash(bundle); return bundle
